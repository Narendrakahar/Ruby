require "test_helper"

class ProdTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
