Rails.application.routes.draw do
  # get 'products/index'
  # get 'products/show'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  root "products#index"
  get "/prod", to: "products#index"
  get "/prod/:id", to: "products#show"

end
