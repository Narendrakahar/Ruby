class Prod < ApplicationRecord
end
