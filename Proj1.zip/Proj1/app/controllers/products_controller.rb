class ProductsController < ApplicationController
  def index
    @Prodc = Prod.all
  end

  def show
    @data = Prod.find(params[:id])
  end

  def new
    @product = Prod.new    
  end

  def create 
    @product = Prod.new(product_params)

    if @Product.save
        redirect to @Product
        else
         render :new, status: :unprocessable_entity
        end
      end
  end


  def product_params
    params.require(:product).permit(:pname, :pprice)
  end
