class HomeController < ApplicationController
  def index
  end

  def projects
  end

  def about
  end

  def contact
  end
end
