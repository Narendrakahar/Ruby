require "test_helper"

class ArticlesControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get articles_index_url
    assert_response :success
  end

  test "should get home" do
    get articles_home_url
    assert_response :success
  end

  test "should get about" do
    get articles_about_url
    assert_response :success
  end

  test "should get contact" do
    get articles_contact_url
    assert_response :success
  end
end
