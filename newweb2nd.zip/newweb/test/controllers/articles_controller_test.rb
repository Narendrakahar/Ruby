require "test_helper"

class ArticlesControllerTest < ActionDispatch::IntegrationTest
  test "should get welcome" do
    get articles_welcome_url
    assert_response :success
  end

  test "should get new" do
    get articles_new_url
    assert_response :success
  end

  test "should get review" do
    get articles_review_url
    assert_response :success
  end
end
