Rails.application.routes.draw do
  # get 'article/index'
  # get 'article/welcome'
  get 'articles/new'
  # get 'article/review'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  root "articles#index"
  get "/articles", to: "articles#index"
  get "/articles/:id", to: "articles#show"
  # get "/articles/:id", to: "articles#new"

end
