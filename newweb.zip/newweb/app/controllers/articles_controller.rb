class ArticlesController < ApplicationController

  def index

      @articles = Article.all
  end


  def show
      @data = Article.find(params[:id])
  end

  def new
  end

  def review
  end
end
